let messages = []; // in-memory (reset tiap deploy baru)

// Simple moderation
const bannedWords = ["spamword1", "badword"];

export default async function handler(req, res) {
  if (req.method === "POST") {
    const body = await parseBody(req);
    const text = String(body.text || "").trim();

    if (!text || text.length > 2000) {
      return res.status(400).json({ message: "Invalid message" });
    }

    const msg = {
      id: Date.now(),
      text,
      createdAt: Date.now(),
      status: "accepted",
    };

    if (bannedWords.some((w) => text.toLowerCase().includes(w))) {
      msg.status = "rejected";
    }

    messages.unshift(msg);
    return res.status(200).json({ status: msg.status });
  }

  if (req.method === "GET") {
    return res.status(200).json(messages.slice(0, 100));
  }

  return res.status(405).json({ message: "Method not allowed" });
}

// helper: parse JSON body
function parseBody(req) {
  return new Promise((resolve) => {
    let data = "";
    req.on("data", (chunk) => (data += chunk));
    req.on("end", () => {
      try {
        resolve(JSON.parse(data));
      } catch {
        resolve({});
      }
    });
  });
}